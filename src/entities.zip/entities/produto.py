from sqlalchemy import Column, Integer, String, Float, Text
from src.entities.base import Base

class Produto(Base):
    __tablename__ = "produto"

    id = Column("id", Integer, primary_key=True, autoincrement=True)
    nome = Column("nome", String(100), nullable=False)
    descricao = Column("descricao", Text, nullable=True)
    preco = Column("preco", Float, nullable=True)
    link_compra = Column("link_compra", String(255), nullable=True)
