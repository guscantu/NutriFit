from sqlalchemy import Column, Integer, String, Float, Enum, Text
from src.entities.base import Base

class Usuario(Base):
    __tablename__ = "usuario"

    id = Column("id", Integer, primary_key=True)
    nome = Column("nome", String(100), nullable=False)
    idade = Column("idade", Integer, nullable=False)
    peso = Column("peso", Float, nullable=False)
    altura = Column("altura", Float, nullable=False)
    objetivo = Column("objetivo", Enum('perder peso', 'ganhar massa muscular', 'manter peso'), nullable=False)
    restricoes = Column("restricoes", Text, nullable=True)
