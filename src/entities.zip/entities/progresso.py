from sqlalchemy import Column, Integer, Float, Date, ForeignKey
from sqlalchemy.orm import relationship
from src.entities.base import Base

class Progresso(Base):
    __tablename__ = "progresso"

    id = Column("id", Integer, primary_key=True, autoincrement=True)
    usuario_id = Column("usuario_id", Integer, ForeignKey("usuario.id"), nullable=False)
    dataprogresso = Column("dataprogresso", Date, nullable=False)
    peso = Column("peso", Float, nullable=False)
    imc = Column("imc", Float, nullable=True)
