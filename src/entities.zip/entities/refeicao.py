from sqlalchemy import Column, Integer, Text, ForeignKey, Enum
from sqlalchemy.orm import relationship
from src.entities.base import Base
import enum

class TipoRefeicao(enum.Enum):
    cafe_da_manha = "café da manhã"
    almoco = "almoço"
    lanche = "lanche"
    jantar = "jantar"

class Refeicao(Base):
    __tablename__ = "refeicao"

    id = Column("id", Integer, primary_key=True, autoincrement=True)
    dieta_id = Column("dieta_id", Integer, ForeignKey("dieta.id"), nullable=False)
    tipo = Column("tipo", Enum(TipoRefeicao), nullable=False)
    alimentos = Column("alimentos", Text, nullable=False)
