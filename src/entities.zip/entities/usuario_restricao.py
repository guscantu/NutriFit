from sqlalchemy import Column, Integer, ForeignKey
from src.entities.base import Base

class UsuarioRestricao(Base):
    __tablename__ = "usuario_restricao"

    usuario_id = Column("usuario_id", Integer, ForeignKey("usuario.id"), primary_key=True)
    restricao_id = Column("restricao_id", Integer, ForeignKey("restricaoalimentar.id"), primary_key=True)