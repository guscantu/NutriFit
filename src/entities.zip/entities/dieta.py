from sqlalchemy import Column, Integer, String, Float, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from src.entities.base import Base

class Dieta(Base):
    __tablename__ = "dieta"

    id = Column("id", Integer, primary_key=True)
    nome = Column("nome", String(100), nullable=False)
    descricao = Column("descricao", Text, nullable=False)
    calorias_total = Column("calorias_total", Float, nullable=False)
    data_criacao = Column("data_criacao", DateTime, nullable=False)
    
    usuario_id = Column("usuario_id", Integer, ForeignKey("usuario.id"), nullable=False)
