from sqlalchemy import Column, Integer, Text, Enum
from src.entities.base import Base
import enum

class Objetivo(enum.Enum):
    perder_peso = "perder peso"
    ganhar_massa_muscular = "ganhar massa muscular"
    manter_peso = "manter peso"

class Dica(Base):
    __tablename__ = "dica"

    id = Column("id", Integer, primary_key=True, autoincrement=True)
    objetivo = Column("objetivo", Enum(Objetivo), nullable=False)
    texto = Column("texto", Text, nullable=False)